# Azure IaC with Terraform and GitHub Actions

## Overview
This project provisions a secure, private Azure infrastructure using Terraform and automates deployment via GitHub Actions.

### Resources Deployed
- Resource Group
- Virtual Network + Subnet + NSG
- Storage Account (private access only)
- App Service Plan + Web App (integrated with VNet)
- Optional: Private Endpoint and Key Vault integration

### Security Hardening
- Public access disabled for storage
- No public IPs used
- Web App integrated with VNet
- NSG allows only internal traffic

### Setup
1. Create Azure Service Principal and save credentials in GitHub Secrets:
   - ARM_CLIENT_ID
   - ARM_CLIENT_SECRET
   - ARM_SUBSCRIPTION_ID
   - ARM_TENANT_ID

2. Push code to `main` branch.

3. GitHub Actions automatically deploys resources.

### Output
The workflow will output the Web App private URL.
